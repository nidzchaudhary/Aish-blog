<?php 
/* Template Name: about template */ ?>

<?php get_header(); ?>

<?php the_content(); ?> 
 
<?php get_footer(); ?>
